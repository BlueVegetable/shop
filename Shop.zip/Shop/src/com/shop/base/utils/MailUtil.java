package com.shop.base.utils;

import java.util.Properties;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.*;

public class MailUtil {
	public static void sendEmail(String email,String messageAll) {
		Properties properties = new Properties();

		// 开启debug调试
		properties.setProperty("mail.debug", "true");
		// 发送服务器需要身份验证
		properties.setProperty("mail.smtp.auth", "true");
		// 设置邮件服务器主机名
		properties.setProperty("mail.host", "smtp.qq.com");
		// 发送邮件协议名称
		properties.setProperty("mail.transport.protocol", "smtp");
		// 设置加密
		properties.put("mail.smtp.ssl.enable", "true");

		// 设置发件人收件人
		String send = "2601042086@qq.com";
		String password = "hndvofspxrccecgj";
		String subject = "来自荣镔商城的消息";

		Session session = Session.getInstance(properties);
		Message message = new MimeMessage(session);

		
		try {
			// 邮件标题
			message.setSubject(subject);
			StringBuilder builder = new StringBuilder();

			// 邮件内容
			builder.append(messageAll);
			message.setText(builder.toString());
			message.setFrom(new InternetAddress(send));

			Transport transport = session.getTransport();
			transport.connect("smtp.qq.com", send, password);

			transport.sendMessage(message,new Address[] {new InternetAddress(email)});
			transport.close();
		} catch (MessagingException e) {
			e.printStackTrace();
		}
	}
	/**
	 * 商城特定的发送邮件的方法
	 * @param email
	 * @param message
	 */
	public static void sendEmailParticular(String toEmail,String message) {
		new Thread(new Runnable() {
			public void run() {
				sendEmail(toEmail,message);
			}
		}).start();
	}
}
//rjvtkgemaxmddigg
//hndvofspxrccecgj