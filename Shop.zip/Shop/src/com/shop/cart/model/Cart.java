package com.shop.cart.model;

import java.math.BigDecimal;
import java.util.*;

import com.shop.goods.model.Goods;
import com.shop.user.model.User;

public class Cart {
	
	private long id;
	private User user;
	private Map<CartItem,Long>cartItems;//Long为ShopID
	private java.util.Date time;

	public Cart(User user) {
		this.id=System.currentTimeMillis();
		this.user=user;
		cartItems=new LinkedHashMap<>();
		this.time=new java.util.Date(System.currentTimeMillis());
	}
	public Cart() {
		
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public java.util.Date getTime() {
		return time;
	}
	public void setTime(java.util.Date time) {
		this.time = time;
	}
	public Map<CartItem,Long> getCartItems() {
		return cartItems;
	}
	public void setCartItems(Map<CartItem,Long> cartItems) {
		this.cartItems = cartItems;
	}
	public void add(CartItem cartItem,long shopID,Goods goods) {
		CartItem cartItemOriginal=null;
		for(CartItem cartItemTest:cartItems.keySet()) {
			if(cartItem.getGoods().getId()==cartItemTest.getGoods().getId()) {
				cartItemOriginal=cartItemTest;
				break;
			}
		}
		if(cartItemOriginal!=null) {
			int allNumber=cartItemOriginal.getNumber()+cartItem.getNumber();
			if(allNumber>goods.getAmount())
				allNumber=goods.getAmount();
			cartItemOriginal.setNumber(allNumber);
		} else {
			cartItems.put(cartItem, shopID);
		}
	}
	public void clear() {
		cartItems.clear();
	}
	public void delete(long cartItemID) {
		for(CartItem cartItem:cartItems.keySet()) 
			if(cartItem.getId()==cartItemID) {
				cartItems.remove(cartItem);
				break;
			}
	}
//	public Collection<CartItem> getCartItems(){
//		
//	}
//	public void setCartItem(CartItem cartItem) {
//		if(cartItems==null) {
//			cartItems=new LinkedHashMap<>();
//			cartItems.put(cartItem.getId(),cartItem);
//		} else {
//			CartItem cartItemOriginal=null;
//			for(long i=0;i<cartItems.size();i++) {
//				if(cartItem.getId()==cartItems.get(i).getId())
//				{
//					cartItemOriginal=cartItems.get(i);
//					break;
//				}
//			}
//			if(cartItemOriginal!=null) {
//				cartItemOriginal.setNumber(cartItemOriginal.getNumber()+cartItem.getNumber());
//			} else {
//				cartItems.put(cartItem.getId(), cartItem);
//			}
//		}
//	}
	public void removeCartItem(long cartItemID) {
		CartItem cartItemOriginal=null;
		for(CartItem cartItem:cartItems.keySet()) {
			if(cartItem.getId()==cartItemID)
				cartItemOriginal=cartItem;
		}
		if(cartItemOriginal!=null)
			cartItems.remove(cartItemOriginal);
	}
	public void clearCartItem() {
		cartItems.clear();
	}
	public double getAllPrice() {
		BigDecimal allPrice=new BigDecimal("0");
		for(CartItem cartItem:cartItems.keySet()) {
			BigDecimal price=new BigDecimal(""+cartItem.getSubtotal());
			allPrice=allPrice.add(price);
		}
		return allPrice.setScale(2, BigDecimal.ROUND_HALF_UP).doubleValue();
	}
	public String toString() {
		return "Cart [id=" + id + ", user=" + user + ", cartItems=" + cartItems + ", time=" + time + "]";
	}
}