package com.shop.goods.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shop.cart.dao.RecorderCart;
import com.shop.cart.model.*;
import com.shop.goods.dao.RecorderGoods;
import com.shop.goods.model.Goods;
import com.shop.member.model.Member;

@WebServlet("/BuyGoods")
public class BuyGoods extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session=request.getSession();
		Member member=(Member)session.getAttribute("member");
		if(member==null) {
			request.setAttribute("msg", "请先登录");
			request.getRequestDispatcher("login.jsp").forward(request, response);
			return ;
		}
		
		long goodsID=Long.parseLong(request.getParameter("goodsID"));
		long shopID=Long.parseLong(request.getParameter("shopID"));
		int goodsNumber=Integer.parseInt(request.getParameter("goodsNumber"));
		
		if(goodsNumber==0) {
			response.sendRedirect("myCart.jsp");
			return ;
		}
		
		Cart cart=(Cart)session.getAttribute("cart");
		Goods goods=RecorderGoods.getGoods(goodsID);
		
		CartItem cartItem=new CartItem();
		cartItem.setGoods(goods);
		cartItem.setNumber(goodsNumber);
		cartItem.setId(System.currentTimeMillis());
		cart.add(cartItem, shopID,goods);
		
		if(!RecorderCart.alterCart(cart))
			cart.delete(cartItem.getId());
		
		response.sendRedirect("myCart.jsp");
	}
}