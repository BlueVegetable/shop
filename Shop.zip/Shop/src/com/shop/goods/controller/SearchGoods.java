package com.shop.goods.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/SearchGoods")
public class SearchGoods extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String operation=request.getParameter("operation");
		switch(operation) {
		case "寻找商品":request.getRequestDispatcher("SearchGoodsByName").forward(request, response);return ;
		case "寻找商店":request.getRequestDispatcher("SearchShop").forward(request, response);return;
		case "寻找类型":request.getRequestDispatcher("SearchGoodsByType").forward(request, response);return ;
		default:response.sendRedirect("search.jsp");return;
		}
	}
}