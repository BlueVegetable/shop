package com.shop.shop.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shop.shop.dao.RecorderShop;
import com.shop.shop.model.Shop;

@WebServlet("/SearchShop")
public class SearchShop extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String shopName=request.getParameter("name");
		ArrayList<Shop>shops=RecorderShop.getShopByName(shopName);
		HttpSession session=request.getSession();
		session.setAttribute("searchResultShops", shops);
		response.sendRedirect("searchStoreResult.jsp");
	}
}