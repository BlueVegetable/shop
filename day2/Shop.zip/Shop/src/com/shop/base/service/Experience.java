package com.shop.base.service;

import java.util.LinkedHashMap;

import com.shop.base.utils.MD5;
import com.shop.base.utils.MailUtil;
import com.shop.cart.dao.RecorderCart;
import com.shop.cart.dao.RecorderCartItem;
import com.shop.cart.model.Cart;
import com.shop.cart.model.CartItem;
import com.shop.goods.dao.RecorderGoods;
import com.shop.member.dao.RecorderMember;
import com.shop.member.model.Member;
import com.shop.order.dao.RecorderOrder;
import com.shop.order.dao.RecorderOrderItem;
import com.shop.order.model.Order;
import com.shop.order.model.OrderItem;
import com.shop.order.util.OrderStatus;
import com.shop.shop.dao.RecorderShop;
import com.shop.shop.model.Shop;
import com.shop.user.dao.RecorderUser;
import com.shop.user.model.User;

@SuppressWarnings("unused")
public class Experience {
	public static void main(String[] args) {
//		System.out.println(RecorderShop.getShopByName("电工杂物店"));
		RecorderShop.getShopByName("电工杂物店");
	}
}