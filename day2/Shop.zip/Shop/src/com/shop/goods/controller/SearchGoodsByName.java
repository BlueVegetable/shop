package com.shop.goods.controller;

import java.io.IOException;
import java.util.LinkedHashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shop.goods.dao.RecorderGoods;
import com.shop.goods.model.Goods;
import com.shop.shop.model.Shop;

@WebServlet("/SearchGoodsByName")
public class SearchGoodsByName extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session=request.getSession();
		String goodsName=request.getParameter("name");
		LinkedHashMap<Goods, Shop>searchGoodsByNameResult = RecorderGoods.searchGoodsByName(goodsName);
		session.setAttribute("goodsNameResult", searchGoodsByNameResult);
		response.sendRedirect("searchResultByName.jsp");
	}
}