package com.shop.order.controller;

import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shop.cart.model.Cart;
import com.shop.cart.model.CartItem;
import com.shop.member.model.Member;
import com.shop.order.model.Order;
import com.shop.order.model.OrderItem;
import com.shop.order.util.OrderStatus;

@WebServlet("/CreateOrder")
public class CreateOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session=request.getSession();
		Cart cart=(Cart) session.getAttribute("cart");//得到购物车
		Member member=(Member) session.getAttribute("member");//获取当前用户
		Map<CartItem, Long> cartItems=cart.getCartItems();//得到购物车内部所有条目
		//不过,其中的Long并不是cartItemID,而是shopID,代表该购物条目所要寄往的商家id
		
		Cart cartTemp=new Cart();//局部购物车的购物车条目,将其初始化,并不存入数据库
		cartTemp.setId(cart.getId());
		cartTemp.setTime(cart.getTime());
		cartTemp.setUser(member.getUser());
		cartTemp.setCartItems(new LinkedHashMap<CartItem,Long>());
		
		//获取选中的购物车的条目
		String[]cartItemIDs=request.getParameterValues("cartItemID");
		LinkedHashSet<Long>shopIDs=new LinkedHashSet<>();//商店条目录
		
		//将大购物车所有被选中的条目存入小购物车中
		for(String cartItemID:cartItemIDs) {
			long cartItemIDValue=Long.parseLong(cartItemID);//将获取到的选中的购物车id转化为数字
			
			for(Entry<CartItem, Long> cartItem:cartItems.entrySet()) {
				if(cartItem.getKey().getId()==cartItemIDValue){
					cartTemp.add(cartItem.getKey(), cartItem.getValue(), cartItem.getKey().getGoods());
					shopIDs.add(cartItem.getValue());//将商店条目存入商店条目录中
					break;
				}
			}
		}
		
		
		//创建订单总集,订单的个数为商家的个数
		ArrayList<Order>orders=new ArrayList<>();
		
		//对小购物车的各个购物条目进行分类,按商店id分类
		for(long shopID:shopIDs) {
			//创建一个新的订单，并初始化基本数据
			
			Order order=new Order();
			
			//为了使订单的id不相同
			try {
				Thread.sleep(2);
			} catch (InterruptedException e) {
				e.printStackTrace();
			}
			order.setId(System.currentTimeMillis());
			
			order.setStatus(OrderStatus.NO_COMFIRM);
			order.setTime(new java.util.Date(System.currentTimeMillis()));
			order.setUser(member.getUser());

			LinkedHashMap<Long,OrderItem>orderItems=new LinkedHashMap<>();
			
			//寻找与之对应的商家的订单条目
			for(Entry<CartItem,Long> cartItem:cartTemp.getCartItems().entrySet()) {
				if(cartItem.getValue()==shopID) {
					OrderItem orderItem=new OrderItem();
					orderItem.setGoods(cartItem.getKey().getGoods());
					orderItem.setGoodsNumber(cartItem.getKey().getNumber());
					orderItem.setId(cartItem.getKey().getId());
					orderItem.setTime(new java.util.Date(System.currentTimeMillis()));
					orderItems.put(orderItem.getId(), orderItem);
				}
			}
			
			
			//将订单条目存入订单中
			order.setOrderItems(orderItems);
			//将订单存入订单条目中
			orders.add(order);
		}
		
		//删除购物车相对应的条目
//		for(CartItem cartItem:cartTemp.getCartItems().keySet()) {
//			RecorderCartItem.deleteCartItem(cartItem.getId());
//			cart.removeCartItem(cartItem.getId());
//		}
		
		//将生成的新的订单存入session
		session.setAttribute("createOrders", orders);
		response.sendRedirect("createOrder.jsp");
	}
}