package com.shop.order.model;

import java.math.BigDecimal;

import com.shop.goods.model.Goods;

public class OrderItem {
	private long id;
	private String address;
	private java.util.Date time;
	private int goodsNumber;
	private Goods goods;
	
	public Goods getGoods() {
		return goods;
	}
	public void setGoods(Goods goods) {
		this.goods = goods;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public java.util.Date getTime() {
		return time;
	}
	public void setTime(java.util.Date time) {
		this.time = time;
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public int getGoodsNumber() {
		return goodsNumber;
	}
	public void setGoodsNumber(int goodsNumber) {
		this.goodsNumber = goodsNumber;
	}
	public double getSubtotal() {
		BigDecimal total=new BigDecimal(""+goodsNumber);
		BigDecimal one=new BigDecimal(goods.getPrice()+"");
		total=total.multiply(one);
		return total.doubleValue();
	}
	public String toString() {
		return "OrderItem [id=" + id + ", address=" + address + ", time=" + time + ", goodsNumber="
				+ goodsNumber + ", goods=" + goods + "]";
	}
}