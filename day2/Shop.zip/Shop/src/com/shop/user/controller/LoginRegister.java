package com.shop.user.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shop.base.controller.BaseServlet;
import com.shop.cart.dao.RecorderCart;
import com.shop.cart.model.Cart;
import com.shop.member.dao.RecorderMember;
import com.shop.member.model.Member;
import com.shop.order.dao.RecorderOrder;
import com.shop.order.model.Order;
import com.shop.role.model.Role;
import com.shop.user.dao.RecorderUser;
import com.shop.user.model.User;

@WebServlet("/LoginRegister")
public class LoginRegister extends BaseServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	}
	public String login(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userID=request.getParameter("id");
		String password=request.getParameter("password");
		HttpSession session=request.getSession();
		
		User user=RecorderUser.getUser(userID);
		if(password.equals(user.getPassword()))
		{
			Member member=RecorderMember.getMember(userID);
			session.setAttribute("member", member);
			
			//购物车初始化
			Cart cart=RecorderCart.getCartByUserID(userID);
			session.setAttribute("cart", cart);
			
			//初始化订单
			ArrayList<Order>orders=RecorderOrder.getOrderByUserID(userID);
			session.setAttribute("orders", orders);
			
			//特权部分A:商家初始化
			if(member.getRole().getId()==2) {
				
			}
			
			
			return "r:mainShow.jsp";
		}else {
			request.setAttribute("msg", "用户名与密码不相符");
			return "f:login.jsp";
		}
	}
	public String register(HttpServletRequest request,HttpServletResponse response) {
		String id=request.getParameter("id");
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String gender=request.getParameter("gender");
		String email=request.getParameter("email");
		String phoneNumber=request.getParameter("phoneNumber");
		
		if(RecorderUser.isExit(id)) {
			request.setAttribute("msg", "用户已经存在");
			return "f:register.jsp";
		}
		
		User user=new User();
		user.setId(id);
		user.setName(name);
		user.setPassword(password);
		user.setGender(gender);
		user.setEmail(email);
		user.setPhoneNumber(phoneNumber);
		Role role=Role.getRole("用户");
		Member member=new Member();
		member.setUser(user);
		member.setRole(role);
		
		if(RecorderMember.addMember(member)) {
			request.setAttribute("msg", "注册成功，请登陆");
			return "f:login.jsp";
		} else {
			request.setAttribute("msg", "注册失败,请重新注册");
			return "f:register.jsp";
		}
	}
}
