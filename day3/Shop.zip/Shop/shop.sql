/*
SQLyog Ultimate v11.33 (64 bit)
MySQL - 5.7.19-log : Database - shop
*********************************************************************
*/

/*!40101 SET NAMES utf8 */;

/*!40101 SET SQL_MODE=''*/;

/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
CREATE DATABASE /*!32312 IF NOT EXISTS*/`shop` /*!40100 DEFAULT CHARACTER SET utf8 */;

USE `shop`;

/*Table structure for table `cart` */

DROP TABLE IF EXISTS `cart`;

CREATE TABLE `cart` (
  `cartID` bigint(20) NOT NULL,
  `userID` varchar(10) NOT NULL,
  `time` date NOT NULL,
  PRIMARY KEY (`cartID`),
  KEY `userID` (`userID`),
  CONSTRAINT `cart_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `cart` */

insert  into `cart`(`cartID`,`userID`,`time`) values (1527527692692,'1000000003','2018-05-29'),(1527575086495,'1000000010','2018-05-29'),(1527608113217,'1000000011','2018-05-29'),(1527643009505,'1000000001','2018-05-30'),(1527645653060,'1000000005','2018-05-30'),(1527692909595,'1000000006','2018-05-30');

/*Table structure for table `cartitem` */

DROP TABLE IF EXISTS `cartitem`;

CREATE TABLE `cartitem` (
  `cartItemID` bigint(20) NOT NULL,
  `goodsID` bigint(20) NOT NULL,
  `goodsNumber` int(11) NOT NULL,
  `cartID` bigint(20) NOT NULL,
  PRIMARY KEY (`cartItemID`),
  KEY `goodsID` (`goodsID`),
  KEY `cartID` (`cartID`),
  CONSTRAINT `cartitem_ibfk_1` FOREIGN KEY (`goodsID`) REFERENCES `goods` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `cartitem_ibfk_2` FOREIGN KEY (`cartID`) REFERENCES `cart` (`cartID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `cartitem` */

/*Table structure for table `goods` */

DROP TABLE IF EXISTS `goods`;

CREATE TABLE `goods` (
  `id` bigint(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `price` double NOT NULL,
  `image` varchar(50) DEFAULT NULL,
  `info` varchar(300) NOT NULL,
  `variety` varchar(20) NOT NULL,
  `register` tinyint(1) NOT NULL,
  `amount` int(11) NOT NULL,
  `buyNumber` int(11) NOT NULL,
  `shopID` bigint(20) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `shopID` (`shopID`),
  KEY `varietyID` (`variety`),
  CONSTRAINT `goods_ibfk_1` FOREIGN KEY (`shopID`) REFERENCES `shop` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `goods` */

insert  into `goods`(`id`,`name`,`price`,`image`,`info`,`variety`,`register`,`amount`,`buyNumber`,`shopID`) values (1,'蛋炒饭',2.2,'1.jpg','普通的蛋炒饭','饭',1,979,21,1),(2,'白饭',1,'2.jpg','普通的白饭','饭',1,1000,0,1),(3,'龙虾炒饭',4.2,'3.jpg','加了龙虾','不知道',1,1000,0,1),(4,'炸鸡',10.09,'4.jpg','炸鸡','美食',1,1000,0,3),(5,'北京烤鸭',6.01,'5.jpg','一种烤鸭','美食',1,1000,0,3),(6,'豆沙面包',1,'6.jpg','面包馅是豆沙的','小吃',1,1000,0,4),(7,'水球',0.59,'7.jpg','一颗装了水的可食用的球','小吃',1,1000,0,4),(8,'扫把',15.03,'8.jpg','大扫除工具之一','生活工具',1,980,20,4),(9,'篮球',50.55,'9.jpg','可以打的篮球','运动',1,1000,0,3);

/*Table structure for table `orderitem` */

DROP TABLE IF EXISTS `orderitem`;

CREATE TABLE `orderitem` (
  `orderItemID` bigint(20) NOT NULL,
  `time` date NOT NULL,
  `orderID` bigint(20) NOT NULL,
  `userID` varchar(10) NOT NULL,
  `goodsID` bigint(20) NOT NULL,
  `goodsNumber` int(11) NOT NULL,
  `address` varchar(100) NOT NULL,
  PRIMARY KEY (`orderItemID`),
  KEY `userID` (`userID`),
  KEY `goodsID` (`goodsID`),
  KEY `orderID` (`orderID`),
  CONSTRAINT `orderitem_ibfk_2` FOREIGN KEY (`userID`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `orderitem_ibfk_3` FOREIGN KEY (`goodsID`) REFERENCES `goods` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `orderitem_ibfk_5` FOREIGN KEY (`orderID`) REFERENCES `orders` (`orderID`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `orderitem` */

insert  into `orderitem`(`orderItemID`,`time`,`orderID`,`userID`,`goodsID`,`goodsNumber`,`address`) values (1527702503959,'2018-05-31',1527702507884,'1000000006',1,10,'广东工业大学'),(1527703179972,'2018-05-31',1527703183494,'1000000006',8,20,'广东工业大学西区'),(1527737629730,'2018-05-31',1527737687126,'1000000003',1,1,'广东工业大学');

/*Table structure for table `orders` */

DROP TABLE IF EXISTS `orders`;

CREATE TABLE `orders` (
  `orderID` bigint(20) NOT NULL,
  `userID` varchar(10) NOT NULL,
  `address` varchar(100) NOT NULL,
  `time` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`orderID`,`userID`),
  KEY `userID` (`userID`),
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `orders` */

insert  into `orders`(`orderID`,`userID`,`address`,`time`,`status`) values (1527702507884,'1000000006','广东工业大学','2018-05-31',1),(1527703183494,'1000000006','广东工业大学西区','2018-05-31',1),(1527737687126,'1000000003','广东工业大学','2018-05-31',1);

/*Table structure for table `role` */

DROP TABLE IF EXISTS `role`;

CREATE TABLE `role` (
  `id` int(11) NOT NULL,
  `name` varchar(20) NOT NULL,
  `title` varchar(20) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `role` */

insert  into `role`(`id`,`name`,`title`) values (1,'user','用户'),(2,'manager','商家'),(3,'admin','管理员');

/*Table structure for table `shop` */

DROP TABLE IF EXISTS `shop`;

CREATE TABLE `shop` (
  `id` bigint(20) NOT NULL,
  `name` varchar(20) NOT NULL,
  `register` tinyint(1) NOT NULL,
  `userID` varchar(10) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `userID` (`userID`),
  CONSTRAINT `shop_ibfk_1` FOREIGN KEY (`userID`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `shop` */

insert  into `shop`(`id`,`name`,`register`,`userID`) values (1,'饭的世界',1,'1000000002'),(3,'健强美食店',1,'1000000010'),(4,'艺隽小吃店',1,'1000000011'),(1527645721342,'北淼专卖店',1,'1000000005');

/*Table structure for table `user` */

DROP TABLE IF EXISTS `user`;

CREATE TABLE `user` (
  `id` varchar(10) NOT NULL,
  `name` varchar(20) NOT NULL,
  `password` varchar(100) NOT NULL,
  `gender` varchar(5) NOT NULL,
  `email` varchar(30) NOT NULL,
  `phoneNumber` varchar(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `user` */

insert  into `user`(`id`,`name`,`password`,`gender`,`email`,`phoneNumber`) values ('1000000001','蔡荣镔','40433343a063d26054a3169b42b5957f','boy','2601042086@qq.com','15521131057'),('1000000002','蜡笔小新','7450fdf04f365909db63d481f90fe79a','boy','2438062943@qq.com','12345678901'),('1000000003','李昕楠','31dc7d8a606d133ed9a68720f949506f','boy','2438062943@qq.com','12345678901'),('1000000004','东杉','9211e6e1b1841180a878f7a5f87dd103','boy','2438062943@qq.com','12345678901'),('1000000005','北淼','eae608e643ccc9ef17347d8c0db548f3','boy','2438062943@qq.com','12345678901'),('1000000006','西钊','9b3e24bb90c3b76a01bfce20dfcad148','boy','2438062943@qq.com','12345678901'),('1000000007','坤中','7b451256bcf54f098a4cf983f9dd98ed','boy','2438062943@qq.com','12345678901'),('1000000008','美真','ac1fd49a12dea81485984156f7f7a7b8','girl','2438062943@qq.com','12345678901'),('1000000009','小贤','3d391c3e2c983ecc10ecc4d416897e9f','girl','2438062943@qq.com','12345678909'),('1000000010','廖健强','a3f39cbff71204d79c955cd614a87a32','boy','2438062943@qq.com','12345678901'),('1000000011','张艺隽','3c28e82d4a0bb4c21a9b9ada5b6ebfeb','boy','2438062943@qq.com','12345678901');

/*Table structure for table `user_role` */

DROP TABLE IF EXISTS `user_role`;

CREATE TABLE `user_role` (
  `user_id` varchar(10) NOT NULL,
  `role_id` int(11) NOT NULL,
  PRIMARY KEY (`user_id`,`role_id`),
  KEY `role_id` (`role_id`),
  CONSTRAINT `user_role_ibfk_1` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `user_role_ibfk_2` FOREIGN KEY (`role_id`) REFERENCES `role` (`id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `user_role` */

insert  into `user_role`(`user_id`,`role_id`) values ('1000000003',1),('1000000004',1),('1000000006',1),('1000000007',1),('1000000009',1),('1000000002',2),('1000000005',2),('1000000008',2),('1000000010',2),('1000000011',2),('1000000001',3);

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;
