package com.shop.goods.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.shop.goods.dao.RecorderGoods;
import com.shop.goods.model.Goods;
import com.shop.shop.model.Shop;

@WebServlet("/AddGoods")
public class AddGoods extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		Shop shop=(Shop) session.getAttribute("shop");
		
		DiskFileItemFactory factory=new DiskFileItemFactory();
		ServletFileUpload sfu=new ServletFileUpload(factory);
		try {
			List<FileItem>fileItemList=sfu.parseRequest(request);
			Goods goods=new Goods();
			
			goods.setId(System.currentTimeMillis());
			for(FileItem fileItem:fileItemList) {
				switch(fileItem.getFieldName()) {
				case "goodsName":goods.setName(fileItem.getString("utf-8"));break;
				case "goodsPrice":goods.setPrice(fileItem.getString("utf-8"));break;
				case "goodsInfo":goods.setInfo(fileItem.getString("utf-8"));break;
				case "goodsVariety":goods.setVariety(fileItem.getString("utf-8"));break;
				case "goodsAmount":goods.setAmount(Integer.parseInt(fileItem.getString("utf-8")));break;
				case "goodsPicture":
					if(fileItem.getName().equals("")||fileItem.getName().equals(null)) {
						goods.setImage("-1.jpg");
						break;
					}
					if(!fileItem.getContentType().equals("image/jpg")&&!fileItem.getContentType().equals("image/jpeg")) {
						request.setAttribute("msg", "上传文件类型错误,请重新上传");
						request.getRequestDispatcher("addGoods.jsp").forward(request, response);
						return ;
					}
					goods.setImage(goods.getId()+".jpg");
					String path=this.getServletContext().getRealPath("")+"goodsImage\\"+goods.getId()+".jpg";
					fileItem.write(new File(path));
					break;
				default:break;
				}
				goods.setBuyNumber(0);
				goods.setRegister(false);
			}
			if(RecorderGoods.addGoods(shop, goods)){
				shop.getCommodities().put(goods.getId(), goods);
				request.setAttribute("msg", "商品创建成功,请耐性等候管理员审核");
				request.getRequestDispatcher("addGoodsResult.jsp").forward(request, response);
				return ;
			}
		} catch (FileUploadException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		request.setAttribute("msg", "商品创建失败");
		request.getRequestDispatcher("addGoodsResult.jsp").forward(request, response);
	}
}