package com.shop.goods.controller;

import java.io.IOException;
import java.util.Map;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shop.base.controller.BaseServlet;
import com.shop.base.utils.MailUtil;
import com.shop.goods.dao.RecorderGoods;
import com.shop.goods.model.Goods;
import com.shop.user.model.User;

@WebServlet("/AdminOperateGoods")
public class AdminOperateGoods extends BaseServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().println("无操作");
	}
	public String agree(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		
		long goodsID=Long.parseLong(request.getParameter("goodsID"));
		@SuppressWarnings("unchecked")
		Map<Goods,User>commodities=(Map<Goods, User>) session.getAttribute("unRegisterGoods");
		for(Entry<Goods,User>commodity:commodities.entrySet()) {
			if(commodity.getKey().getId()==goodsID) {
				Goods goods=commodity.getKey();
				User user=commodity.getValue();
				
				if(RecorderGoods.setRegister(goods.getId(), true)) {
					String message="亲爱的"+user.getName()+",您的商品:"+goods.getName()+"已经通过审核.";
					MailUtil.sendEmailParticular(user.getEmail(), message);
					commodities.remove(goods);
				}
				break;
			}
		}
		return "r:goodsOnShop.jsp";
	}
	public String disagree(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session=request.getSession();
		
		long goodsID=Long.parseLong(request.getParameter("goodsID"));
		@SuppressWarnings("unchecked")
		Map<Goods,User>commodities=(Map<Goods, User>) session.getAttribute("unRegisterGoods");
		for(Entry<Goods,User>commodity:commodities.entrySet()) {
			if(commodity.getKey().getId()==goodsID) {
				Goods goods=commodity.getKey();
				User user=commodity.getValue();
				
				if(RecorderGoods.deleteGoods(goodsID)) {
					String message="亲爱的"+user.getName()+",很遗憾您的商品:"+goods.getName()+"不能通过审核.";
					MailUtil.sendEmailParticular(user.getEmail(), message);
					commodities.remove(goods);
				}
				break;
			}
		}
		
		return "r:goodsOnShop.jsp";
	}
}