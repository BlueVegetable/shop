package com.shop.goods.controller;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import com.shop.goods.dao.RecorderGoods;
import com.shop.goods.model.Goods;
import com.shop.shop.model.Shop;

@WebServlet("/AlterGoods")
public class AlterGoods extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session=request.getSession();
		Shop shop=(Shop) session.getAttribute("shop");
		long goodsID=0;
		
		DiskFileItemFactory factory=new DiskFileItemFactory();
		ServletFileUpload sfu=new ServletFileUpload(factory);
		try {
			List<FileItem>fileItemList=sfu.parseRequest(request);
			Goods goods=new Goods();
			
			for(FileItem fileItem:fileItemList) {
				switch(fileItem.getFieldName()) {
				case "goodsID":goodsID=Long.parseLong(fileItem.getString("utf-8"));goods.setId(goodsID);break;
				case "goodsName":goods.setName(fileItem.getString("utf-8"));break;
				case "goodsPrice":goods.setPrice(fileItem.getString("utf-8"));break;
				case "goodsInfo":goods.setInfo(fileItem.getString("utf-8"));break;
				case "goodsVariety":goods.setVariety(fileItem.getString("utf-8"));break;
				case "goodsAmount":goods.setAmount(Integer.parseInt(fileItem.getString("utf-8")));break;
				case "goodsPicture":goods.setImage(fileItem.getName());
					
					if(!goods.getImage().equals("")&&goods.getImage()==null)
					{
						if(!fileItem.getContentType().equals("image/jpg")&&!fileItem.getContentType().equals("image/jpeg")) {
							request.setAttribute("msg", "上传文件类型错误,请重新上传");
							request.getRequestDispatcher("addGoods.jsp").forward(request, response);
							return ;
						}
						
						String path=this.getServletContext().getRealPath("")+"goodsImage\\"+goods.getId()+".jpg";
						fileItem.write(new File(path));
					}
					break;
				default:break;
				}
				
			}
			
			Goods goodsOriginal=RecorderGoods.getGoods(goodsID);
			goods.setImage(goodsOriginal.getImage());
			goods.setBuyNumber(goodsOriginal.getBuyNumber());
			goods.setRegister(goodsOriginal.isRegister());
			
			if(RecorderGoods.alterGoods(goods)){
				shop.getCommodities().replace(goodsID, goods);
				request.setAttribute("msg", "商品修改成功");
				request.getRequestDispatcher("addGoodsResult.jsp").forward(request, response);
				return ;
			}
		} catch (FileUploadException e) {
			e.printStackTrace();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		request.setAttribute("msg", "商品修改失败");
		request.getRequestDispatcher("addGoodsResult.jsp").forward(request, response);
	}
}