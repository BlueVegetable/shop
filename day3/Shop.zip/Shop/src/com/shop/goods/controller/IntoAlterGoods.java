package com.shop.goods.controller;

import java.io.IOException;
import java.util.LinkedHashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shop.base.controller.BaseServlet;
import com.shop.goods.model.Goods;
import com.shop.shop.model.Shop;

@WebServlet("/IntoAlterGoods")
public class IntoAlterGoods extends BaseServlet {
	private static final long serialVersionUID = 1L;
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		intoAlter(request,response);
	}
	public String intoAlter(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session=request.getSession();
		
		long goodsID=Long.parseLong(request.getParameter("goodsID"));
		Shop shop=(Shop)session.getAttribute("shop");
		LinkedHashMap<Long, Goods> commodities=shop.getCommodities();
		Goods goods=commodities.get(goodsID);
		request.setAttribute("commodity", goods);
		
		return "f:alterGoodsInfo.jsp";
	}
}