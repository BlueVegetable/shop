package com.shop.goods.controller;

import java.io.IOException;
import java.util.LinkedHashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shop.goods.dao.RecorderGoods;
import com.shop.goods.model.Goods;
import com.shop.shop.model.Shop;

@WebServlet("/SearchGoodsByType")
public class SearchGoodsByType extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session=request.getSession();
		String goodsType=request.getParameter("name");
		LinkedHashMap<Goods, Shop> searchGoodsByTypeResult=RecorderGoods.searchGoodsByType(goodsType);
		session.setAttribute("goodsTypeResult",searchGoodsByTypeResult );
		response.sendRedirect("searchResultByType.jsp");
	}
}