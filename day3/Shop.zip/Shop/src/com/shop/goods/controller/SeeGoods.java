package com.shop.goods.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shop.goods.dao.RecorderGoods;
import com.shop.goods.model.Goods;

@WebServlet("/SeeGoods")
public class SeeGoods extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		long goodsID=Long.parseLong(request.getParameter("goodsID"));
		Goods goods=RecorderGoods.getGoods(goodsID);
		request.setAttribute("goods", goods);
		request.setAttribute("shopID", request.getParameter("shopID"));
		request.setAttribute("amount", request.getParameter("amount"));
		request.getRequestDispatcher("goodsShow.jsp").forward(request, response);
	}
}