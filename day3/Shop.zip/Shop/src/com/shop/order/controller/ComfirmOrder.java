package com.shop.order.controller;

import java.io.IOException;
import java.util.*;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shop.cart.dao.RecorderCartItem;
import com.shop.cart.model.Cart;
import com.shop.goods.dao.RecorderGoods;
import com.shop.goods.model.Goods;
import com.shop.order.dao.RecorderOrder;
import com.shop.order.model.Order;
import com.shop.order.model.OrderItem;

@WebServlet("/ComfirmOrder")
public class ComfirmOrder extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session=request.getSession();
		String address=request.getParameter("address");
		
		@SuppressWarnings("unchecked")
		ArrayList<Order>createOrders=(ArrayList<Order>) session.getAttribute("createOrders");
		Cart cart=(Cart) session.getAttribute("cart");//获取购物车
		
		for(Order order:createOrders) {
			
			//生成订单存入数据库
			order.setAddress(address);
			order.setAllAddress(address);
			RecorderOrder.addOrder(order);
			
			LinkedHashMap<Long, OrderItem> orderItems=order.getOrderItems();
			for(Entry<Long, OrderItem> orderItem:orderItems.entrySet()) {
				Goods goods=orderItem.getValue().getGoods();
				
				int buyNumber=goods.getBuyNumber()+orderItem.getValue().getGoodsNumber();
				int amount=goods.getAmount()-orderItem.getValue().getGoodsNumber();
				
				//后台改变商品相应的数量
				RecorderGoods.setBuyNumber(goods.getId(), buyNumber);
				RecorderGoods.setGoodsAmount(goods, amount);
				
				//获取订单条目编号
				long orderItemID=orderItem.getKey();
				if(RecorderCartItem.deleteCartItem(orderItemID))
					cart.delete(orderItemID);//因为订单条目编号与购物车条目编号相同
			}
			
			//前端改变订单相应的信息
			@SuppressWarnings("unchecked")
			ArrayList<Order> orders=(ArrayList<Order>) session.getAttribute("orders");
			orders.add(order);
		}
		response.sendRedirect("myOrder.jsp");
	}
}