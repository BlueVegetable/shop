package com.shop.order.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map.Entry;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shop.base.controller.BaseServlet;
import com.shop.goods.dao.RecorderGoods;
import com.shop.goods.model.Goods;
import com.shop.order.dao.RecorderOrder;
import com.shop.order.model.Order;
import com.shop.order.model.OrderItem;
import com.shop.order.util.OrderStatus;

@WebServlet("/UserOperateOrder")
public class UserOperateOrder extends BaseServlet{
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	}
	public String cancelOrder(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		long orderID=Long.parseLong(request.getParameter("orderID"));
		HttpSession session=request.getSession();
		
		//取出前端的订单
		@SuppressWarnings("unchecked")
		ArrayList<Order>orders=(ArrayList<Order>) session.getAttribute("orders");
		
		Order orderOriginal=null;
		//找到要删除的order
		for(Order order:orders)
			if(order.getId()==orderID)
				orderOriginal=order;
		
		if(RecorderOrder.deleteOrder(orderID))
			orders.remove(orderOriginal);
		
		/**
		 * 恢复商品的数目
		 */
		LinkedHashMap<Long, OrderItem> orderItems=orderOriginal.getOrderItems();
		for(Entry<Long,OrderItem> orderItem:orderItems.entrySet()) {
			long goodsID=orderItem.getValue().getGoods().getId();//之所以要去除id是为了保证数据库中的内容正确
			
			Goods goods=RecorderGoods.getGoods(goodsID);
			
			int goodsNumber=orderItem.getValue().getGoodsNumber();
			int amount=goods.getAmount()+goodsNumber;
			int buyNumber=goods.getBuyNumber()-goodsNumber;
			
			goods.setAmount(amount);
			goods.setBuyNumber(buyNumber);
			if(RecorderGoods.alterGoods(goods)) {
				Goods goodsOriginal=orderItem.getValue().getGoods();
				goodsOriginal.setAmount(amount);
				goodsOriginal.setBuyNumber(buyNumber);
			}
		}
		
		return "r:myOrder.jsp";
	}
	public String orderBeGot (HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		long orderID=Long.parseLong(request.getParameter("orderID"));
		Order orderOriginal=null;
		
		@SuppressWarnings("unchecked")
		ArrayList<Order>orders=(ArrayList<Order>) session.getAttribute("orders");
		for(Order order:orders)
			if(order.getId()==orderID)
				orderOriginal=order;
		
		OrderStatus orderStatus=orderOriginal.getStatus();
		orderOriginal.setStatus(OrderStatus.GET);
		if(!RecorderOrder.resetOrderStatus(orderOriginal))
			orderOriginal.setStatus(orderStatus);
		
		return "r:myOrder.jsp";
	}
	public String deleteOrder(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session=request.getSession();
		long orderID=Long.parseLong(request.getParameter("orderID"));
		Order orderOriginal=null;
		
		@SuppressWarnings("unchecked")
		ArrayList<Order>orders=(ArrayList<Order>) session.getAttribute("orders");
		
		for(Order order:orders)
			if(order.getId()==orderID)
				orderOriginal=order;
		
		if(RecorderOrder.deleteOrder(orderID))
			orders.remove(orderOriginal);
		return "r:myOrder.jsp";
	}
}