package com.shop.order.model;

import java.math.BigDecimal;
import java.util.LinkedHashMap;

import com.shop.order.util.OrderStatus;
import com.shop.user.model.User;

public class Order {
	private long id;
	private User user;
	private String address;
	private java.util.Date time;
	private OrderStatus status;
	private LinkedHashMap<Long,OrderItem>orderItems;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public User getUser() {
		return user;
	}
	public void setUser(User user) {
		this.user = user;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
//		for(OrderItem orderItem:orderItems.values()) {
//			orderItem.setAddress(address);
//		}
	}
	public void setAllAddress(String address) {
		for(OrderItem orderItem:orderItems.values())
			orderItem.setAddress(address);
	}
	public java.util.Date getTime() {
		return time;
	}
	public void setTime(java.util.Date time) {
		this.time = time;
	}
	public LinkedHashMap<Long, OrderItem> getOrderItems() {
		return orderItems;
	}
	public void setOrderItems(LinkedHashMap<Long, OrderItem> orderItems) {
		this.orderItems = orderItems;
	}
	public OrderStatus getStatus() {
		return status;
	}
	public void setStatus(OrderStatus status) {
		this.status = status;
	}
	public String getStatusValue() {
		return OrderStatus.getStatusString(this.status);
	}
	public int getStatusNumber() {
		return OrderStatus.getStatusData(this.status);
	}
	public double getTotal() {
		BigDecimal total=new BigDecimal("0");
		for(OrderItem orderItem:orderItems.values()) {
			BigDecimal one=new BigDecimal(""+orderItem.getSubtotal());
			total=total.add(one);
		}
		return total.doubleValue();
	}
	public void deleteOrderItem(long orderItemID) {
		orderItems.remove(orderItemID);
	}
	public void addOrderItem(OrderItem orderItem) {
		orderItems.put(orderItem.getId(), orderItem);
	}
	public void clearOrderItem() {
		orderItems.clear();
	}
	public String toString() {
		return "Order [id=" + id + ", user=" + user + ", address=" + address + ", time=" + time + ", status=" + status
				+ ", orderItems=" + orderItems + "]";
	}
}