package com.shop.shop.controller;

import java.io.IOException;
import java.util.LinkedHashMap;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shop.base.utils.MailUtil;
import com.shop.goods.model.Goods;
import com.shop.member.model.Member;
import com.shop.shop.dao.RecorderShop;
import com.shop.shop.model.Shop;
import com.shop.user.model.User;

@WebServlet("/ApplyOpenShop")
public class ApplyOpenShop extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session=request.getSession();
		request.setAttribute("shopName", request.getParameter("shopName"));
		if(session.getAttribute("member")==null)
		{
			request.setAttribute("msg", "请先登陆");
			request.getRequestDispatcher("login.jsp").forward(request, response);
			return ;
		}
		String operation=request.getParameter("operation");
		switch(operation) {
		case "获取验证码":getVerifyNumber(request,response);break;
		default:judgeVerifyNumber(request,response);break;
		}
	}
	private void getVerifyNumber(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session=request.getSession();
		String openShowNumber="";
		String value="0123456789";//待选字符数组
		for(int i=0;i<6;i++) {
			String k=""+value.charAt((int)(Math.random()*10));//临时变量
			openShowNumber=openShowNumber+k;
		}
		session.setAttribute("openShowNumber", openShowNumber);
		Member member=(Member) session.getAttribute("member");
		User user=member.getUser();
		MailUtil.sendEmailParticular(user.getEmail(), "您开店申请的验证码为"+openShowNumber);
		request.getRequestDispatcher("applyOpenShop.jsp").forward(request, response);
	}
	private void judgeVerifyNumber(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session=request.getSession();
		Member member=(Member)session.getAttribute("member");
		String openShowNumbe=(String) session.getAttribute("openShowNumber");
		
		if(openShowNumbe==null)
		{
			request.setAttribute("msg", "请先获取验证码");
			request.getRequestDispatcher("applyOpenShop.jsp").forward(request, response);
			return ;
		}
		String value=request.getParameter("ApplyShopNumber");
		if(!openShowNumbe.equals(value))
		{
			request.setAttribute("msg", "验证码输入错误");
			request.getRequestDispatcher("applyOpenShop.jsp").forward(request, response);
			return ;
		}
		session.removeAttribute("openShowNumber");
		Shop shop=new Shop();
		shop.setId(System.currentTimeMillis());
		shop.setName(request.getParameter("shopName"));
		shop.setRegister(false);
		
		LinkedHashMap<Long, Goods> commodities=new LinkedHashMap<>();
		shop.setCommodities(commodities);
		shop.setShopper(member);
		if(RecorderShop.addShop(shop))
			response.sendRedirect("openShopSuccess.jsp");
		else
			response.sendRedirect("openShopFail.jsp");
	}
}