package com.shop.shop.controller;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shop.shop.model.Shop;

@WebServlet("/IntoStore")
public class IntoStore extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		long shopID=Long.parseLong(request.getParameter("shopID"));
		HttpSession session=request.getSession();
		Shop shopOriginal=null;
		
		@SuppressWarnings("unchecked")
		ArrayList<Shop> shops=(ArrayList<Shop>) session.getAttribute("searchResultShops");
		for(Shop shop:shops) {
			if(shop.getId()==shopID) {
				shopOriginal=shop;
			}
		}
		request.setAttribute("intoShop", shopOriginal);
		request.getRequestDispatcher("intoStore.jsp").forward(request, response);
		return ;
	}
}
