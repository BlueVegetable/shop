package com.shop.user.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shop.base.controller.BaseServlet;
import com.shop.goods.dao.RecorderGoods;
import com.shop.goods.model.Goods;
import com.shop.shop.dao.RecorderShop;
import com.shop.shop.model.Shop;
import com.shop.user.model.User;

@WebServlet("/AdminFresh")
public class AdminFresh extends BaseServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	}
	public String refreshGoods(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session=request.getSession();
		Map<Goods,User>commodities=RecorderGoods.getAllUnRegistedGoods();
		session.setAttribute("unRegisterGoods", commodities);
		return "r:goodsOnShop.jsp";
	}
	public String refreshUnRegisterShop(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session=request.getSession();
		ArrayList<Shop> shops=RecorderShop.getAllUnRegisterShop();
		session.setAttribute("unRegisterShop", shops);
		return "r:agreeOpenShop.jsp";
	}
	public String refreshRegisterShop(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session=request.getSession();
		ArrayList<Shop>shops=RecorderShop.getAllRegisterShop();
		session.setAttribute("registerShop", shops);
		return "r:closeShop.jsp";
	}
}