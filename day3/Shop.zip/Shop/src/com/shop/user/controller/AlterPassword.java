package com.shop.user.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.shop.base.utils.MailUtil;
import com.shop.user.dao.RecorderUser;
import com.shop.user.model.User;

@WebServlet("/AlterPassword")
public class AlterPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String userID=request.getParameter("userID");
		
		if(userID==null||!RecorderUser.isExit(userID)) {
			request.setAttribute("msg", "用户不存在");
			request.getRequestDispatcher("forgetPassword.jsp").forward(request, response);
			return ;
		}
		
		User user=RecorderUser.getUser(userID);
		String password=request.getParameter("password");
		if(RecorderUser.alterPassword(userID, password)) {
			String message="亲爱的"+user.getName()+",您密码修改已经完成,请登录";
			MailUtil.sendEmailParticular(user.getEmail(), message);
		} else {
			String message="亲爱的"+user.getName()+",您的密码修改失败";
			MailUtil.sendEmailParticular(user.getEmail(), message);
		}
		response.sendRedirect("login.jsp");
	}
}