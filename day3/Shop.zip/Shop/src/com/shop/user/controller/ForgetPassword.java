package com.shop.user.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shop.base.utils.MailUtil;
import com.shop.user.dao.RecorderUser;
import com.shop.user.model.User;

@WebServlet("/ForgetPassword")
public class ForgetPassword extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session=request.getSession();
		
		String userID=request.getParameter("userID");
		
		request.setAttribute("userID", userID);
		if(!RecorderUser.isExit(userID)) {
			request.setAttribute("msg", "用户不存在");
			request.getRequestDispatcher("forgetPassword.jsp").forward(request, response);
			return ;
		}
		
		User user=RecorderUser.getUser(userID);
		String email=user.getEmail();
		
		String opt="0123456789";
		String forgetNumber="";
		for(int i=0;i<6;i++) {
			int number=(int)(Math.random()*opt.length());
			forgetNumber=forgetNumber+opt.charAt(number);
		}
		MailUtil.sendEmailParticular(email, "您本次修改密码的验证码为:"+forgetNumber);
		session.setAttribute("forgetNumber", forgetNumber);
		request.setAttribute("msg", "请输入验证码");
		request.getRequestDispatcher("forgetPassword.jsp").forward(request, response);
	}
}