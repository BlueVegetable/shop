package com.shop.user.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shop.base.controller.BaseServlet;
import com.shop.base.utils.MD5;
import com.shop.cart.dao.RecorderCart;
import com.shop.cart.model.Cart;
import com.shop.goods.dao.RecorderGoods;
import com.shop.goods.model.Goods;
import com.shop.member.dao.RecorderMember;
import com.shop.member.model.Member;
import com.shop.order.dao.RecorderOrder;
import com.shop.order.model.Order;
import com.shop.role.model.Role;
import com.shop.shop.dao.RecorderShop;
import com.shop.shop.model.Shop;
import com.shop.user.dao.RecorderUser;
import com.shop.user.model.User;

@WebServlet("/LoginRegister")
public class LoginRegister extends BaseServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	}
	public String login(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		HttpSession session=request.getSession();
		
		//验证码处理
		String yanzhengma=request.getParameter("yanzhengma");
		String loginNumber=(String) session.getAttribute("loginNumber");
		if(!yanzhengma.equals(loginNumber)) {
			request.setAttribute("msg", "验证码错误");
			return "f:login.jsp";
		}
		
		String userID=request.getParameter("id");
		String password=request.getParameter("password");
		password=MD5.toMD5(password);
		
		User user=RecorderUser.getUser(userID);
		if(password.equals(user.getPassword()))
		{
			Member member=RecorderMember.getMember(userID);
			session.setAttribute("member", member);
			
			//购物车初始化
			Cart cart=RecorderCart.getCartByUserID(userID);
			session.setAttribute("cart", cart);
			
			//初始化订单
			ArrayList<Order>orders=RecorderOrder.getOrderByUserID(userID);
			session.setAttribute("orders", orders);
			
			//特权部分A:商家初始化
			if(member.getRole().getId()==2) {
				Shop shop=RecorderShop.getShopByUserID(member.getUser().getId());
				session.setAttribute("shop", shop);
				ArrayList<Order>receiveOrders=RecorderOrder.getOrderByShopperID(member.getUser().getId());
				session.setAttribute("receiveOrders", receiveOrders);
			}
			
			//特权部分B:管理员初始化
			if(member.getRole().getId()==3) {
				//初始化商家开店申请
				ArrayList<Shop>shops = RecorderShop.getAllUnRegisterShop();
				session.setAttribute("unRegisterShop", shops);
				//初始化商品上架
				Map<Goods,User>commodities=new LinkedHashMap<>();
				commodities.putAll(RecorderGoods.getAllUnRegistedGoods());
				session.setAttribute("unRegisterGoods", commodities);
				//初始化已经注册的商家
				ArrayList<Shop> registedShops=RecorderShop.getAllRegisterShop();
				session.setAttribute("registerShop", registedShops);
			}
			
			return "r:mainShow.jsp";
		}else {
			request.setAttribute("msg", "用户名与密码不相符");
			return "f:login.jsp";
		}
	}
	public String register(HttpServletRequest request,HttpServletResponse response) {
		String id=request.getParameter("id");
		String name=request.getParameter("name");
		String password=request.getParameter("password");
		String gender=request.getParameter("gender");
		String email=request.getParameter("email");
		String phoneNumber=request.getParameter("phoneNumber");
		
		if(RecorderUser.isExit(id)) {
			request.setAttribute("msg", "用户已经存在");
			return "f:register.jsp";
		}
		
		User user=new User();
		user.setId(id);
		user.setName(name);
		user.setPassword(MD5.toMD5(password));
		user.setGender(gender);
		user.setEmail(email);
		user.setPhoneNumber(phoneNumber);
		Role role=Role.getRole("用户");
		Member member=new Member();
		member.setUser(user);
		member.setRole(role);
		
		if(RecorderMember.addMember(member)) {
			request.setAttribute("msg", "注册成功，请登陆");
			return "f:login.jsp";
		} else {
			request.setAttribute("msg", "注册失败,请重新注册");
			return "f:register.jsp";
		}
	}
}
