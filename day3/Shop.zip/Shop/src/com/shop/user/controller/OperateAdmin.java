package com.shop.user.controller;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.shop.base.controller.BaseServlet;
import com.shop.base.utils.MailUtil;
import com.shop.goods.dao.RecorderGoods;
import com.shop.member.dao.RecorderMember;
import com.shop.member.model.Member;
import com.shop.role.dao.RecorderRole;
import com.shop.role.model.Role;
import com.shop.shop.dao.RecorderShop;
import com.shop.shop.model.Shop;
import com.shop.user.dao.RecorderUser;
import com.shop.user.model.User;

@WebServlet("/OperateAdmin")
public class OperateAdmin extends BaseServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
	}
	public String agree(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		@SuppressWarnings("unchecked")
		List<Shop>shops=(List<Shop>) session.getAttribute("unRegisterShop");
		Shop shopOriginal=null;
		long shopID=Long.parseLong(request.getParameter("shopID"));
		String userID=request.getParameter("userID");
		
		for(Shop shop:shops)
			if(shopID==shop.getId()) {
				shopOriginal=shop;
				break;
			}
		if(RecorderShop.setRegister(shopID, true)&&RecorderRole.alterRole(userID, Role.getRole(2))) {
			shops.remove(shopOriginal);
			Member member=RecorderMember.getMember(userID);
			String message="亲爱的"+member.getUser().getName()+",您好.恭喜你已经成为荣镔商城的商家,请重新登录";
			MailUtil.sendEmailParticular(member.getUser().getEmail(), message);
		}
		
		return "r:agreeOpenShop.jsp";
	}
	public String disagree(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		@SuppressWarnings("unchecked")
		List<Shop>shops=(List<Shop>) session.getAttribute("unRegisterShop");
		Shop shopOriginal=null;
		long shopID=Long.parseLong(request.getParameter("shopID"));
		String userID=request.getParameter("userID");
		
		for(Shop shop:shops)
			if(shopID==shop.getId()) {
				shopOriginal=shop;
				break;
			}
		if(RecorderShop.deleteShop(shopID)) {
			shops.remove(shopOriginal);
			Member member=RecorderMember.getMember(userID);
			String message="亲爱的"+member.getUser().getName()+",您好.很抱歉,管理员不同意您的开店申请.";
			MailUtil.sendEmailParticular(member.getUser().getEmail(), message);
		}
		
		return "r:agreeOpenShop.jsp";
	}
	public String refresh(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		ArrayList<Shop>shops=RecorderShop.getAllUnRegisterShop();
		HttpSession session=request.getSession();
		session.setAttribute("unRegisterShop", shops);
		return "r:agreeOpenShop.jsp";
	}
	public String deleteShop(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		HttpSession session=request.getSession();
		long shopID=Long.parseLong(request.getParameter("shopID"));
		String userID=request.getParameter("userID");
		if(RecorderShop.setRegister(shopID, false)&&RecorderRole.alterRole(userID, Role.getRole(1))) {
			//本来应该是要删除整个商店的，不过考虑到可能要扩展功能：商家申诉，因此决定只是先关闭商家的权力
			@SuppressWarnings("unchecked")
			ArrayList<Shop>shops=(ArrayList<Shop>) session.getAttribute("registerShop");
			
			
			for(int i=0;i<shops.size();i++)
				if(shops.get(i).getId()==shopID) {
					Shop shop=shops.get(i);
					for(long commodityID:shop.getCommodities().keySet())//取消商品的已注册属性
						RecorderGoods.setRegister(commodityID, false);
					shops.remove(shop);
					break;
				}
			User user=RecorderUser.getUser(userID);
			String message="您好,"+user.getName()+",您已经被管理员取消了商家的资格";
			MailUtil.sendEmailParticular(user.getEmail(), message);
		}
		
		return "r:closeShop.jsp";
	}
}