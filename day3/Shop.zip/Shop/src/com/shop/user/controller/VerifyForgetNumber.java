package com.shop.user.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/VerifyForgetNumber")
public class VerifyForgetNumber extends HttpServlet {
	private static final long serialVersionUID = 1L;
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {		
		HttpSession session=request.getSession();
		if(session.getAttribute("forgetNumber")==null) {
			request.setAttribute("msg", "请先获取验证码");
			request.getRequestDispatcher("forgetPassword.jsp").forward(request, response);
		}
		String forgetNumber=(String) session.getAttribute("forgetNumber");
		session.removeAttribute("forgetNumber");
		String forgetNumber2=request.getParameter("forgetNumber");
		if(forgetNumber.equals(forgetNumber2)) {
			request.setAttribute("userID", request.getParameter("userID"));
			request.getRequestDispatcher("alterPassword.jsp").forward(request, response);
			return ;
		}else {
			request.setAttribute("msg", "验证码输入错误,请重新获取");
			request.getRequestDispatcher("forgetPassword.jsp").forward(request, response);
			return ;
		}
	}
}